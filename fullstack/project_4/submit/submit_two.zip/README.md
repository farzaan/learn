# Instructions to run the code

## By Farzaan Nasar

To run the code execute the following:
	
```python
	python logs_analysis.py

```

The results are in the following files:

* author_report.txt
* error_rates.txt
* view_report.txt