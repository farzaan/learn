# course-ud303

This repository contains downloadable exercise code for the Udacity course
"HTTP and Web Servers".  The exercises are written in portable Python 3 and
HTML.

