# Lesson 2

There are eight downloadable exercises in Lesson 2 of this course.

* The hello server
* The echo server
* HTML forms
* The messageboard server, part one (POST requests)
* The messageboard server, part two (GET and POST)
* The messageboard server, part three (POST-Redirect-GET)
* The JSON client demo
* The bookmark server

