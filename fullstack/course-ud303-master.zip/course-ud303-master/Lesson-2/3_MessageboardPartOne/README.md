# Messageboard, Part One

In this exercise, you'll start building a messageboard server.  The server
will accept a form submitted via HTTP POST, so the first thing to do is to
make a server that accepts a POST and just echoes the contents back to the
browser.

See `MessageboardPartOne.py` for the starter code and instructions.
