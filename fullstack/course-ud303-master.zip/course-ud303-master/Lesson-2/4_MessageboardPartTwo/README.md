# Messageboard, Part Two

In this exercise, you'll give the messageboard server the ability to serve
its own form. A GET request to the server will return the form, while a POST
request (submitting the form) will echo back the message.

See `MessageboardPartTwo.py` for the starter code and instructions.

