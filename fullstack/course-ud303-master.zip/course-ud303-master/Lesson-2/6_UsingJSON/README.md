# Using JSON

In this exercise, you'll decode JSON data in an HTTP response from the site
`uinames.com`.

Take a look at `UINames.py` for the starter code and instructions.

