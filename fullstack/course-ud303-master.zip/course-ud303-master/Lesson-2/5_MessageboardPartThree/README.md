# Messageboard, Part Three

In this exercise, you'll complete the messageboard server using the
Post-Redirect-Get design.

See `MessageboardPartThree.py` for the starter code and instructions.
