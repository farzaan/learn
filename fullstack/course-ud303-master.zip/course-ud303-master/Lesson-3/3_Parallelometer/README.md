# Parallelometer

This is a web server that demonstrates the number of simultaneous connections
your browser opens to a web server.

Run `Parallelometer.py` in your terminal, then access it
in your browser at http://localhost:8000.  You should see sixteen small
frames in the window, each of which displays the number of active connections
that the server is handling at that moment.

