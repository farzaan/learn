# Lesson 3

There are three downloadable exercises in Lesson 3 of this course:

1. The threaded server patch
2. The cookie name server
3. The parallel requests experiment

