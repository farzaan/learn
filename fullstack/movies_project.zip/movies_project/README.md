# Movie Trailer Project

### Files
* entertainment_center.py - Contains instances of movie
* media.py - contains class Movie
* fresh_tomatoes.py - contains fresh_tomatoes

### Usage
Download and open movie_project.zip file
Type `python entertainment_center.py` into any console